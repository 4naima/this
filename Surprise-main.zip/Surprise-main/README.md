
  # For naima

  This is a code bundle for For naima. The original project is available at https://www.figma.com/design/87lR7g3mOm0Ik0zBLIz8JE/For-naima.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  