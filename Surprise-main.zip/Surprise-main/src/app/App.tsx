import { useState, useRef } from 'react';
import { PasswordGate } from './components/PasswordGate';
import { CountdownTimer } from './components/CountdownTimer';
import { EnvelopeLetter } from './components/EnvelopeLetter';
import { GiftBox } from './components/GiftBox';
import { EnvelopeGiftCard } from './components/EnvelopeGiftCard';
import { GiftCard } from './components/GiftCard';
import { BackgroundMusic, BackgroundMusicHandle } from './components/BackgroundMusic';

type Stage = 'password' | 'countdown' | 'letter' | 'gifts' | 'envelope' | 'giftcard';

export default function App() {
  const [currentStage, setCurrentStage] = useState<Stage>('password');
  const backgroundMusicRef = useRef<BackgroundMusicHandle>(null);

  // Set target date to March 8, 2026
  // For testing, you can use a date in the near future like: new Date(Date.now() + 10000) // 10 seconds from now
  const birthdayDate = new Date('2026-03-08T00:00:00');

  const handleGiftBoxOpen = () => {
    // Mute background music when giftbox is opened
    backgroundMusicRef.current?.mute();
  };

  const handleGiftBoxComplete = () => {
    // Unmute background music when proceeding from giftbox
    backgroundMusicRef.current?.unmute();
    setCurrentStage('envelope');
  };

  return (
    <div className="min-h-screen">
      <BackgroundMusic ref={backgroundMusicRef} />



      {currentStage === 'password' && (
        <PasswordGate onUnlock={() => setCurrentStage('countdown')} />
      )}

      {currentStage === 'countdown' && (
        <CountdownTimer
          targetDate={birthdayDate}
          onComplete={() => setCurrentStage('letter')}
          onBack={() => setCurrentStage('password')}
        />
      )}

      {currentStage === 'letter' && (
        <EnvelopeLetter 
          onComplete={() => setCurrentStage('gifts')}
          onBack={() => setCurrentStage('countdown')}
        />
      )}

      {currentStage === 'gifts' && (
        <GiftBox 
          onComplete={handleGiftBoxComplete}
          onOpen={handleGiftBoxOpen}
          onBack={() => {
            backgroundMusicRef.current?.unmute();
            setCurrentStage('letter');
          }}
        />
      )}

      {currentStage === 'envelope' && (
        <EnvelopeGiftCard 
          onComplete={() => setCurrentStage('giftcard')}
          onBack={() => setCurrentStage('gifts')}
        />
      )}

      {currentStage === 'giftcard' && (
        <GiftCard onBack={() => setCurrentStage('envelope')} />
      )}
    </div>
  );
}