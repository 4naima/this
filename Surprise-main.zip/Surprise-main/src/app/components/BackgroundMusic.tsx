import { useEffect, useRef, forwardRef, useImperativeHandle } from 'react';

export interface BackgroundMusicHandle {
  mute: () => void;
  unmute: () => void;
}

export const BackgroundMusic = forwardRef<BackgroundMusicHandle>((_, ref) => {
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const fadeIntervalRef = useRef<number | null>(null);

  useEffect(() => {
    const audio = new Audio('');
    audio.loop = true;
    audio.preload = 'auto';
    audio.volume = 1;
    audioRef.current = audio;

    const tryPlayAudio = () => {
      if (!audioRef.current) return;
      audioRef.current.play().catch(() => {
        console.log('Autoplay blocked, waiting for interaction');
      });
    };

    // Play immediately if tab is visible
    if (!document.hidden) {
      tryPlayAudio();
    }

    // Handle tab visibility change
    const handleVisibilityChange = () => {
      if (!audioRef.current) return;
      if (document.hidden) {
        audioRef.current.pause(); // pause if tab inactive
      } else {
        tryPlayAudio(); // play again if tab active
      }
    };

    document.addEventListener('visibilitychange', handleVisibilityChange);

    return () => {
      if (fadeIntervalRef.current) clearInterval(fadeIntervalRef.current);
      audio.pause();
      audio.src = '';
      document.removeEventListener('visibilitychange', handleVisibilityChange);
    };
  }, []);

  const fadeOut = () => {
    if (!audioRef.current) return;

    let volume = audioRef.current.volume;
    if (fadeIntervalRef.current) clearInterval(fadeIntervalRef.current);

    fadeIntervalRef.current = window.setInterval(() => {
      if (!audioRef.current) return;

      volume -= 0.05;
      if (volume <= 0) {
        volume = 0;
        audioRef.current.volume = 0;
        audioRef.current.muted = true;
        audioRef.current.pause();
        if (fadeIntervalRef.current) clearInterval(fadeIntervalRef.current);
      } else {
        audioRef.current.volume = volume;
      }
    }, 50);
  };

  const fadeIn = () => {
    if (!audioRef.current) return;

    audioRef.current.muted = false;
    let volume = 0;
    audioRef.current.volume = 0;

    if (fadeIntervalRef.current) clearInterval(fadeIntervalRef.current);

    // play if paused
    if (audioRef.current.paused && !document.hidden) {
      audioRef.current.play().catch(() => {});
    }

    fadeIntervalRef.current = window.setInterval(() => {
      if (!audioRef.current) return;

      volume += 0.05;
      if (volume >= 1) {
        volume = 1;
        audioRef.current.volume = 1;
        if (fadeIntervalRef.current) clearInterval(fadeIntervalRef.current);
      } else {
        audioRef.current.volume = volume;
      }
    }, 50);
  };

  useImperativeHandle(ref, () => ({
    mute: fadeOut,
    unmute: fadeIn,
  }));

  return null;
});

BackgroundMusic.displayName = 'BackgroundMusic';