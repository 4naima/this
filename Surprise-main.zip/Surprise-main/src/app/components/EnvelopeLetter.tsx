import { useState, useEffect, useRef } from 'react';
import { ChevronLeft } from 'lucide-react';

interface EnvelopeLetterProps {
  onComplete: () => void;
  onBack: () => void;
}

export function EnvelopeLetter({ onComplete, onBack }: EnvelopeLetterProps) {
  const [showSecondVideo, setShowSecondVideo] = useState(false);

  const firstVideoRef = useRef<HTMLVideoElement>(null);
  const secondVideoRef = useRef<HTMLVideoElement>(null);

  useEffect(() => {
    const firstVideo = firstVideoRef.current;
    const secondVideo = secondVideoRef.current;

    // preload second video
    if (secondVideo) secondVideo.load();

    if (firstVideo) {
      firstVideo.play().catch(() => {});
      firstVideo.onended = () => {
        setShowSecondVideo(true);

        if (secondVideo) {
          secondVideo.currentTime = 0;
          secondVideo.play().catch(() => {});
        }
      };
    }
  }, []);

  return (
    <div className="min-h-screen w-full fixed inset-0 overflow-hidden bg-white">

      {/* Back Button */}
      <button
        onClick={onBack}
        className="fixed top-4 left-4 z-50 p-2 rounded-full bg-white/20 backdrop-blur-sm border border-white/30 hover:bg-white/30"
        style={{ color: '#fff' }}
      >
        <ChevronLeft className="w-6 h-6" />
      </button>

      <div className="absolute inset-0 w-full h-full">

        {/* First Video */}
        <video
          ref={firstVideoRef}
          src="https://res.cloudinary.com/dcne65hbw/video/upload/w_720,q_auto:low,f_auto,vc_auto/again_typewritter_1_vzn0x4.mp4"
          muted
          playsInline
          preload="auto"
          className="w-full h-full object-cover select-none absolute inset-0"
          style={{ visibility: showSecondVideo ? 'hidden' : 'visible' }}
        />

        {/* Second Video (Trimmed on Cloudinary & looped naturally) */}
        <video
          ref={secondVideoRef}
          src="https://res.cloudinary.com/dcne65hbw/video/upload/w_720,q_auto:low,f_auto,vc_auto,so_0,eo_14/again_typewritter_2_vwdzco.mp4"
          muted
          playsInline
          preload="auto"
          loop
          className="w-full h-full object-cover select-none absolute inset-0"
          style={{ visibility: showSecondVideo ? 'visible' : 'hidden' }}
        />
      </div>

      {showSecondVideo && (
        <div className="absolute z-10 w-full text-center" style={{ bottom: '10%' }}>
          <button
            onClick={onComplete}
            className="text-sm sm:text-xl md:text-2xl font-bold cursor-pointer"
            style={{
              fontFamily: 'Georgia, serif',
              border: '2.5px solid #8B593C',
              borderRadius: '50px',
              padding: '0.5rem 1rem',
              color: '#8B593C',
            }}
          >
            Check Your Gifts
          </button>
        </div>
      )}
    </div>
  );
}
