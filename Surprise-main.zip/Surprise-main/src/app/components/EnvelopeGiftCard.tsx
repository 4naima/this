import { useState, useEffect } from 'react';
import { ChevronLeft } from 'lucide-react';

interface EnvelopeGiftCardProps {
  onComplete: () => void;
  onBack: () => void;
}

export function EnvelopeGiftCard({ onComplete, onBack }: EnvelopeGiftCardProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [imagesLoaded, setImagesLoaded] = useState(false);

  const closedEnvelopeUrl = 'https://i.ibb.co.com/LX8H7qWy/new-openning.jpg';
  const openEnvelopeUrl = 'https://i.ibb.co.com/rfQhJVkc/new-closing.jpg';

  useEffect(() => {
    const img1 = new Image();
    const img2 = new Image();

    img1.src = closedEnvelopeUrl;
    img2.src = openEnvelopeUrl;

    let loaded = 0;
    const checkLoaded = () => {
      loaded++;
      if (loaded === 2) {
        setImagesLoaded(true);
      }
    };

    img1.onload = checkLoaded;
    img2.onload = checkLoaded;

    if (img1.complete) checkLoaded();
    if (img2.complete) checkLoaded();
  }, []);

  return (
    <div className="fixed inset-0 w-screen h-screen overflow-hidden">

      {/* 🔹 Instant blurred fallback instead of black */}
      <div
        className="absolute inset-0"
        style={{
          backgroundImage: `url(${closedEnvelopeUrl})`,
          backgroundSize: 'cover',
          backgroundPosition: 'center',
          filter: 'blur(25px)',
          transform: 'scale(1.1)',
        }}
      />

      {/* Back Button */}
      <button
        onClick={onBack}
        className="fixed top-4 left-4 z-50 p-2 rounded-full bg-white/20 backdrop-blur-sm border border-[#6E695E]/30 hover:bg-white/30"
        style={{ color: '#6E695E' }}
      >
        <ChevronLeft className="w-6 h-6" />
      </button>
      
      {/* Closed Image - UNCHANGED */}
      <img
        src={closedEnvelopeUrl}
        alt="Closed Envelope"
        onClick={() => setIsOpen(true)}
        className="absolute inset-0 w-full h-full object-cover select-none cursor-pointer"
        style={{ display: isOpen ? 'none' : 'block' }}
        draggable={false}
      />

      {/* Open Image - UNCHANGED */}
      <img
        src={openEnvelopeUrl}
        alt="Open Envelope"
        className="absolute inset-0 w-full h-full object-cover select-none"
        style={{ display: isOpen ? 'block' : 'none' }}
        draggable={false}
      />

      {/* Button - UNCHANGED */}
      {isOpen && (
        <button
          onClick={onComplete}
          className="absolute bottom-10 left-1/2 -translate-x-1/2 px-7 py-2.5 text-sm rounded-full z-10"
          style={{
            background: 'transparent',
            color: '#fff',
            border: '1px solid rgba(255,255,255,0.6)',
            fontFamily: 'Inter, sans-serif',
            letterSpacing: '1px',
          }}
        >
          Turn the Page
        </button>
      )}
    </div>
  );
}