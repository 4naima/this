import { useState, useEffect } from 'react';

// Import fonts in global CSS:
// @import url('https://fonts.googleapis.com/css2?family=Cardo&display=swap');
// @import url('https://fonts.googleapis.com/css2?family=Courier+Prime&display=swap');

interface PasswordGateProps {
  onUnlock: () => void;
}

export function PasswordGate({ onUnlock }: PasswordGateProps) {
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [bgLoaded, setBgLoaded] = useState(false);

  const correctPassword = 'Naima2026';
  const BG_URL =
    'https://github.com/4naima/gift/blob/main/bjjkukk.jpeg?raw=true';

  useEffect(() => {
    const img = new Image();
    img.src = BG_URL;
    img.onload = () => setBgLoaded(true);
    if (img.complete) setBgLoaded(true);
  }, []);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (password === correctPassword) {
      onUnlock();
    } else {
      setError('Hehe vul,abar dao!');
      setPassword('');
      setTimeout(() => setError(''), 3000);
    }
  };

  return (
    <div className="min-h-screen relative w-full">
      {/* 🔹 Blurred fallback while image loads */}
      {!bgLoaded && (
        <div
          className="absolute inset-0"
          style={{
            backgroundImage: `url('${BG_URL}')`,
            backgroundSize: 'cover',
            backgroundPosition: 'center',
            filter: 'blur(25px)',
            transform: 'scale(1.05)',
          }}
        />
      )}

      {/* Background */}
      {bgLoaded && (
        <div
          className="absolute inset-0"
          style={{
            backgroundImage: `url('${BG_URL}')`,
            backgroundSize: 'cover',
            backgroundPosition: 'center',
            backgroundRepeat: 'no-repeat',
            backgroundColor: '#fff',
          }}
        />
      )}

      {/* Password input */}
      <form onSubmit={handleSubmit}>
        <div
          style={{
            position: 'absolute',
            left: '16.7%',
            top: '70%',
            width: '26%',
            borderBottom: '1px solid black',
          }}
        >
          <input
            type="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            placeholder="Enter the Word"
            style={{
              width: '100%',
              fontFamily: "'Courier Prime', monospace",
              fontSize: '0.7rem',
              color: 'black',
              backgroundColor: 'transparent',
              border: 'none',
              outline: 'none',
              padding: '0px',
            }}
            autoFocus
          />
        </div>
      </form>

      {/* Error message */}
      {error && (
        <p
          style={{
            position: 'absolute',
            left: '16.7%',
            top: '73.5%',
            fontFamily: "'Courier Prime', monospace",
            fontSize: '0.65rem',
            color: '#8B593C',
          }}
        >
          {error}
        </p>
      )}

      {/* Unlock button */}
      <button
        type="submit"
        onClick={handleSubmit}
        className="px-6 py-2 rounded-full font-bold cursor-pointer"
        style={{
          position: 'absolute',
          left: '50%',
          bottom: '9%',
          transform: 'translateX(-50%)',
          backgroundColor: 'transparent',
          border: '2px solid #8B593C',
          color: '#8B593C',
          fontFamily: "'Cardo', serif",
          fontSize: '1rem',
        }}
      >
        Unlock
      </button>
    </div>
  );
}