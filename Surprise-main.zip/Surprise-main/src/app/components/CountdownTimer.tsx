import { useState, useEffect } from 'react';
import { ChevronLeft } from 'lucide-react';

// @import url('https://fonts.googleapis.com/css2?family=Special+Elite&display=swap');

interface CountdownTimerProps {
  targetDate: Date;
  onComplete: () => void;
  onBack: () => void;
}

export function CountdownTimer({ targetDate, onComplete, onBack }: CountdownTimerProps) {
  const [timeLeft, setTimeLeft] = useState({
    days: 0,
    hours: 0,
    minutes: 0,
    seconds: 0,
  });

  const [bgLoaded, setBgLoaded] = useState(false);

  const BG_URL = 'https://i.ibb.co.com/MzZC4MF/new-cntdwn.jpg';

  // Preload background image
  useEffect(() => {
    const img = new Image();
    img.src = BG_URL;
    img.onload = () => setBgLoaded(true);
    if (img.complete) setBgLoaded(true);
  }, []);

  // Countdown logic (UNCHANGED)
  useEffect(() => {
    const calculateTimeLeft = () => {
      const difference = targetDate.getTime() - new Date().getTime();

      if (difference <= 0) {
        onComplete();
        return { days: 0, hours: 0, minutes: 0, seconds: 0 };
      }

      return {
        days: Math.floor(difference / (1000 * 60 * 60 * 24)),
        hours: Math.floor((difference / (1000 * 60 * 60)) % 24),
        minutes: Math.floor((difference / 1000 / 60) % 60),
        seconds: Math.floor((difference / 1000) % 60),
      };
    };

    setTimeLeft(calculateTimeLeft());
    const timer = setInterval(() => setTimeLeft(calculateTimeLeft()), 1000);
    return () => clearInterval(timer);
  }, [targetDate, onComplete]);

  return (
    <div className="min-h-screen w-full fixed inset-0 overflow-hidden">

      {/* 🔹 Blurred Background (Shows Immediately) */}
      <div
        className="absolute inset-0"
        style={{
          backgroundImage: `url('${BG_URL}')`,
          backgroundSize: 'cover',
          backgroundPosition: 'center',
          filter: 'blur(20px)',
          transform: 'scale(1.1)', // prevents white edges from blur
        }}
      />

      {/* 🔹 Sharp Background (Fades In) */}
      <div
        className="absolute inset-0 transition-opacity duration-700"
        style={{
          backgroundImage: `url('${BG_URL}')`,
          backgroundSize: 'cover',
          backgroundPosition: 'center',
          opacity: bgLoaded ? 1 : 0,
        }}
      />

      {/* 🔹 Back Button */}
      <button
        onClick={onBack}
        className="fixed top-4 left-4 z-50 p-2 rounded-full bg-white/20 backdrop-blur-sm border border-white/30 hover:bg-white/30"
        style={{ color: 'white' }}
      >
        <ChevronLeft className="w-6 h-6" />
      </button>

      {/* 🔹 Countdown Content */}
      <div className="relative z-10 w-full h-full flex items-center justify-center px-4">
        <div className="w-full max-w-xs sm:max-w-sm flex flex-col items-center justify-center gap-6">

          {/* Days | Hours */}
          <div className="flex justify-center gap-10">
            {[
              { value: timeLeft.days, label: 'Days' },
              { value: timeLeft.hours, label: 'Hours' },
            ].map((item) => (
              <div key={item.label} className="flex flex-col items-center">
                <div
                  className="text-5xl sm:text-6xl text-black"
                  style={{ fontFamily: "'Patrick Hand', cursive" }}
                >
                  {String(item.value).padStart(2, '0')}
                </div>
                <div
                  className="mt-1 text-sm sm:text-base text-black"
                  style={{ fontFamily: "'Patrick Hand', cursive" }}
                >
                  {item.label}
                </div>
              </div>
            ))}
          </div>

          {/* Minutes | Seconds */}
          <div className="flex justify-center gap-10">
            {[
              { value: timeLeft.minutes, label: 'Minutes' },
              { value: timeLeft.seconds, label: 'Seconds' },
            ].map((item) => (
              <div key={item.label} className="flex flex-col items-center">
                <div
                  className="text-5xl sm:text-6xl text-black"
                  style={{ fontFamily: "'Patrick Hand', cursive" }}
                >
                  {String(item.value).padStart(2, '0')}
                </div>
                <div
                  className="mt-1 text-sm sm:text-base text-black"
                  style={{ fontFamily: "'Patrick Hand', cursive" }}
                >
                  {item.label}
                </div>
              </div>
            ))}
          </div>

        </div>
      </div>

    </div>
  );
}