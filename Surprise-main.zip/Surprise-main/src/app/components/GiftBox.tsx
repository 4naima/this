import { useState, useRef, useEffect } from 'react';
import { ChevronLeft } from 'lucide-react';
// Replaced figma asset with direct URL
const musicBg = 'https://i.ibb.co.com/gZNXXB6X/neww-all-bg.jpg';
import { SongPlaylist } from './SongPlaylist';
import { VoiceNote } from './VoiceNote';

interface GiftBoxProps {
  onComplete: () => void;
  onOpen: () => void;
  onBack: () => void;
}

export function GiftBox({ onComplete, onOpen, onBack }: GiftBoxProps) {
  const [isBoxOpen, setIsBoxOpen] = useState(false);
  const [canProceed, setCanProceed] = useState(false);
  const [currentVideo, setCurrentVideo] = useState<'first' | 'second'>('first');

  const firstVideoRef = useRef<HTMLVideoElement>(null);
  const secondVideoRef = useRef<HTMLVideoElement>(null);

  // Preload both videos immediately on mount
  useEffect(() => {
    const firstVideo = firstVideoRef.current;
    const secondVideo = secondVideoRef.current;

    if (firstVideo) {
      firstVideo.load();
      const playPromise = firstVideo.play();
      if (playPromise !== undefined) {
        playPromise.catch(() => {
          console.log('First video autoplay blocked');
        });
      }
    }

    if (secondVideo) {
      secondVideo.load();
    }
  }, []);

  const handleFirstVideoEnd = () => {
    setCurrentVideo('second');
    if (secondVideoRef.current) {
      const playPromise = secondVideoRef.current.play();
      if (playPromise !== undefined) {
        playPromise.catch(() => console.log('Second video autoplay blocked'));
      }
    }
  };

  const handleBoxClick = () => {
    setIsBoxOpen(true);
    setCanProceed(true);
    onOpen();
  };

  if (!isBoxOpen) {
    return (
      <div className="fixed inset-0 w-screen h-screen overflow-hidden bg-white">
        {/* 🔹 Always render blurred fallback underneath videos */}
        <div
          className="absolute inset-0"
          style={{
            backgroundImage: `url(${musicBg})`,
            backgroundSize: 'cover',
            backgroundPosition: 'center',
            filter: 'blur(30px)',
            transform: 'scale(1.05)',
          }}
        />

        {/* Back Button */}
        <button
          onClick={onBack}
          className="fixed top-4 left-4 z-50 p-2 rounded-full bg-white/20 backdrop-blur-sm border border-white/30 hover:bg-white/30"
          style={{ color: '#fff' }}
        >
          <ChevronLeft className="w-6 h-6" />
        </button>

        {/* First Video */}
        <video
          ref={firstVideoRef}
          autoPlay
          muted
          playsInline
          preload="auto"
          onEnded={handleFirstVideoEnd}
          className="absolute inset-0 w-full h-full object-cover"
          style={{ display: currentVideo === 'first' ? 'block' : 'none' }}
        >
          <source
            src="https://res.cloudinary.com/dcne65hbw/video/upload/gift_item_1st_ab50lm.mp4"
            type="video/mp4"
          />
        </video>

        {/* Second Video */}
        <video
          ref={secondVideoRef}
          loop
          muted
          playsInline
          preload="auto"
          className="absolute inset-0 w-full h-full object-cover"
          style={{ display: currentVideo === 'second' ? 'block' : 'none' }}
        >
          <source
            src="https://res.cloudinary.com/dcne65hbw/video/upload/gift_item_2n_npq0ru.mp4"
            type="video/mp4"
          />
        </video>

        {/* Open Button */}
        {currentVideo === 'second' && (
          <p
            onClick={handleBoxClick}
            className="absolute bottom-12 cursor-pointer text-center w-full z-10"
            style={{ fontFamily: '"Cinzel", serif', fontWeight: 500 }}
          >
            <span
              style={{
                backgroundColor: 'transparent',
                color: 'white',
                padding: '7px 27px',
                borderRadius: '22px',
                border: '2px solid antiquewhite',
                letterSpacing: '1px',
                fontSize: '1.2rem',
                display: 'inline-block',
                cursor: 'pointer',
                userSelect: 'none',
              }}
            >
              Open
            </span>
          </p>
        )}
      </div>
    );
  }

  return (
    <div
      className="min-h-screen relative"
      style={{
        backgroundImage: `url(${musicBg})`,
        backgroundSize: 'cover',
        backgroundPosition: 'center',
        backgroundRepeat: 'no-repeat',
      }}
    >
      {/* Back Button */}
      <button
        onClick={onBack}
        className="fixed top-4 left-4 z-50 p-2 rounded-full bg-white/20 backdrop-blur-sm border border-white/30 hover:bg-white/30"
        style={{ color: 'white' }}
      >
        <ChevronLeft className="w-6 h-6" />
      </button>

      <div className="absolute inset-0 backdrop-blur-[2px] pointer-events-none" />

      <div className="relative z-10 space-y-12 max-w-6xl mx-auto p-4 py-12">
        <SongPlaylist />
        <VoiceNote />

        {canProceed && (
          <div className="text-center pb-8">
            <button
              onClick={onComplete}
              className="px-6 py-2 rounded-full text-lg shadow-sm backdrop-blur-sm bg-white/20 border border-white/30 hover:bg-white/30"
              style={{
                fontFamily: '"Indie Flower", cursive',
                color: '#000',
              }}
            >
              There's More...
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
