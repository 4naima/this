import { useState, useEffect } from 'react';
import { Gift, MapPin, User, Phone, ChevronLeft } from 'lucide-react';

interface GiftCardProps {
  onBack: () => void;
}

export function GiftCard({ onBack }: GiftCardProps) {
  const [formData, setFormData] = useState({
    name: '',
    address: '',
    phone: '',
  });
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [bgLoaded, setBgLoaded] = useState(false);

  const BG_URL =
    'https://i.ibb.co.com/q3Ddv5fm/nneww-last-bg.jpg';

  // Preload background image
  useEffect(() => {
    const img = new Image();
    img.src = BG_URL;
    img.onload = () => setBgLoaded(true);
    if (img.complete) setBgLoaded(true);
  }, []);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    const FORMSPREE_ENDPOINT = 'https://formspree.io/f/xwvnalyw';

    try {
      const response = await fetch(FORMSPREE_ENDPOINT, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name: formData.name,
          address: formData.address,
          phone: formData.phone,
          message: `Birthday gift delivery address for Naima`,
        }),
      });

      if (response.ok) setIsSubmitted(true);
    } catch (error) {
      console.error('Form submission error:', error);
      alert('There was an error. Please try again!');
    }
  };

  return (
    <div className="relative h-screen w-screen overflow-hidden">
      {/* 🔹 Blurred fallback while image loads */}
      {!bgLoaded && (
        <div
          className="absolute inset-0"
          style={{
            backgroundImage: `url('${BG_URL}')`,
            backgroundSize: 'cover',
            backgroundPosition: 'center',
            filter: 'blur(25px)',
            transform: 'scale(1.05)',
          }}
        />
      )}

      {/* Background */}
      {bgLoaded && (
        <div
          className="absolute inset-0"
          style={{
            backgroundImage: `url('${BG_URL}')`,
            backgroundSize: 'cover',
            backgroundPosition: 'center',
            backgroundRepeat: 'no-repeat',
          }}
        />
      )}

      {/* Back Button */}
      <button
        onClick={onBack}
        className="fixed top-4 left-4 z-50 p-2 rounded-full bg-white/20 backdrop-blur-sm border border-[#6E695E]/30 hover:bg-white/30"
        style={{ color: '#6E695E' }}
      >
        <ChevronLeft className="w-6 h-6" />
      </button>

      {/* Content */}
      <div className="relative h-full flex items-center justify-center">
        {!isSubmitted ? (
          <div className="w-full max-w-xl px-6">
            <div
              className="p-8 shadow-2xl"
              style={{
                background: 'rgba(255, 255, 255, 0.40)',
                backdropFilter: 'blur(12px)',
                WebkitBackdropFilter: 'blur(12px)',
                border: '1px solid rgba(255,255,255,0.3)',
                borderRadius: '0px',
              }}
            >
              <div className="mb-4 text-center">
                <h3
                  className="text-xl font-bold text-black mb-2"
                  style={{ fontFamily: 'Georgia, serif' }}
                >
                  The gifts are waiting just for you,  
                  please Naima, share your address💌
                </h3>
                <p
                  className="text-sm text-black"
                  style={{ fontFamily: 'DM Sans, sans-serif' }}
                >
                  Let me know if you'd like to meet and receive the gifts in person.
                </p>
              </div>

              <form onSubmit={handleSubmit} className="space-y-4">
                {/* Name */}
                <div>
                  <label className="block text-left text-sm font-semibold text-black mb-2">
                    <User className="inline w-4 h-4 mr-1" />
                    Full Name (Prettiest)
                  </label>
                  <input
                    type="text"
                    required
                    value={formData.name}
                    onChange={(e) =>
                      setFormData({ ...formData, name: e.target.value })
                    }
                    className="w-full px-4 py-3 border border-white/30 bg-white/10 backdrop-blur-sm focus:outline-none"
                    placeholder="Your name"
                  />
                </div>

                {/* Address */}
                <div>
                  <label className="block text-left text-sm font-semibold text-black mb-2">
                    <MapPin className="inline w-4 h-4 mr-1" />
                    Full Address
                  </label>
                  <input
                    type="text"
                    required
                    value={formData.address}
                    onChange={(e) =>
                      setFormData({ ...formData, address: e.target.value })
                    }
                    className="w-full px-4 py-3 border border-white/30 bg-white/10 backdrop-blur-sm focus:outline-none"
                    placeholder="Your Address"
                  />
                </div>

                {/* Phone */}
                <div>
                  <label className="block text-left text-sm font-semibold text-black mb-2">
                    <Phone className="inline w-4 h-4 mr-1" />
                    Phone Number (Optional)
                  </label>
                  <input
                    type="tel"
                    value={formData.phone}
                    onChange={(e) =>
                      setFormData({ ...formData, phone: e.target.value })
                    }
                    className="w-full px-4 py-3 border border-white/30 bg-white/10 backdrop-blur-sm focus:outline-none"
                    placeholder="For delivery updates"
                  />
                </div>

                <button
                  type="submit"
                  className="w-full py-4 text-white font-bold text-lg"
                  style={{ backgroundColor: '#845E3A', fontFamily: 'DM Sans, sans-serif' }}
                >
                  Let the Gift Find Me
                </button>
              </form>
            </div>
          </div>
        ) : (
          <div className="w-full max-w-xl px-6">
            <div
              className="p-8 shadow-2xl"
              style={{
                background: 'rgba(255, 255, 255, 0.40)',
                backdropFilter: 'blur(12px)',
                WebkitBackdropFilter: 'blur(12px)',
                border: '1px solid rgba(255,255,255,0.3)',
                borderRadius: '0px',
              }}
            >
              <div className="text-center">
                <h2
                  className="text-4xl font-bold mb-2"
                  style={{ fontFamily: 'Georgia, serif' }}
                >
                  Thank You, Naima!😭
                </h2>
                <p
                  className="text-lg"
                  style={{ fontFamily: 'Georgia, serif' }}
                >
                  Your gifts are on its way.
                </p>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}