# 🎂 Birthday Website - Customization Guide

## Overview
This is a personalized, interactive birthday website with multiple stages:
1. **Password Gate** - Private access only
2. **Countdown Timer** - Counts down to March 8, 2026
3. **Envelope & Letter** - Animated letter reveal
4. **Gift Box** - Contains 19 songs and a voice note
5. **Gift Card** - Address collection form

## 🔐 Changing the Password

Edit `/src/app/components/PasswordGate.tsx`:
```typescript
const correctPassword = 'Naima2026'; // Change this to your desired password
```

## 📅 Changing the Birthday Date

Edit `/src/app/App.tsx`:
```typescript
const birthdayDate = new Date('2026-03-08T00:00:00'); // Change to desired date
```

## 🎵 Adding Real Songs

### Option 1: Local Audio Files
1. Add your audio files to `/public` folder (create it if it doesn't exist)
2. Update `/src/app/components/SongPlaylist.tsx`:

```typescript
const songs = [
  { 
    id: 1, 
    title: "Song Name", 
    artist: "Artist Name", 
    duration: "3:45",
    audioUrl: "/path/to/song.mp3", // Add this
    color: "from-pink-300 to-rose-300" 
  },
  // ... more songs
];
```

3. Add an HTML5 audio element and control it:
```typescript
const [audio] = useState(new Audio());

const playSong = (url: string) => {
  audio.src = url;
  audio.play();
};
```

### Option 2: Embed from Streaming Services
Use embed codes from Spotify, Apple Music, or SoundCloud.

## 🎤 Adding a Real Voice Note

1. Record your voice message and save it as an MP3 file
2. Add it to `/public` folder
3. Update `/src/app/components/VoiceNote.tsx`:

```typescript
// Replace the audio ref initialization with:
const audioRef = useRef<HTMLAudioElement>(new Audio('/your-voice-note.mp3'));

// In handleWindMove function, actually control the audio:
if (newProgress > audioProgress) {
  audioRef.current.play();
} else {
  audioRef.current.pause();
}
audioRef.current.currentTime = newProgress * audioRef.current.duration;
```

## 📬 Setting Up Form Submission

### Using Formspree (Free):
1. Go to [formspree.io](https://formspree.io) and create a free account
2. Create a new form and get your endpoint
3. Update `/src/app/components/GiftCard.tsx`:

```typescript
const handleSubmit = async (e: React.FormEvent) => {
  e.preventDefault();
  
  await fetch('https://formspree.io/f/YOUR_FORM_ID', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify(formData),
  });
  
  setIsSubmitted(true);
  // ... confetti code
};
```

### Using EmailJS (Alternative):
1. Go to [emailjs.com](https://www.emailjs.com) and create an account
2. Set up an email service and template
3. Install EmailJS: `npm install @emailjs/browser`
4. Configure in GiftCard.tsx

## 🎨 Customization Tips

### Change Colors
Update the gradient colors throughout the components:
- `from-pink-500 to-purple-500` → Change to your preferred colors
- Look for `bg-gradient-to-*` classes

### Modify Text Content
- **Letter content**: The letter image is already provided, but you can overlay text if needed
- **Gift card message**: Edit in `/src/app/components/GiftCard.tsx`
- **Song dedications**: Edit song titles and artists in `/src/app/components/SongPlaylist.tsx`

### Add More Gifts
In `/src/app/components/GiftBox.tsx`, add more components:
```typescript
<YourCustomGift />
```

## 🚀 Deployment

### Deploy to Vercel (Recommended):
1. Push your code to GitHub
2. Go to [vercel.com](https://vercel.com)
3. Import your repository
4. Deploy!

### Deploy to Netlify:
1. Push to GitHub
2. Go to [netlify.com](https://netlify.com)
3. Import and deploy

### Deploy to GitHub Pages:
1. Run `npm run build`
2. Deploy the `dist` folder

## 📝 Important Notes

- **Privacy**: The current password is `Naima2026` - change it before sharing!
- **Audio Files**: For best performance, use MP3 format and keep files under 5MB
- **Testing**: Test the countdown with a near-future date first
- **Mobile**: The site is fully responsive and works on all devices

## 🎁 Making it Extra Special

### Ideas to enhance:
1. Add background music to each section
2. Include a photo gallery slideshow
3. Add more interactive animations
4. Create a video message section
5. Add a memory timeline

## 💝 Final Touch

Remember to replace:
- [ ] Password in PasswordGate.tsx
- [ ] Birthday date in App.tsx
- [ ] Song titles and audio files
- [ ] Voice note audio file
- [ ] Form submission endpoint
- [ ] Any personalized messages

Enjoy creating this special gift! ✨
